<?php
    $con = mysqli_connect('localhost','root','','miniproject');     
    $username =$_POST['username'];  
    $password = $_POST['password'];
    $phoneno = $_POST['phoneno'];
      $address = $_POST['address'];
       $email = $_POST['email'];
    $ds = $_POST['ds'];
    $vehicle_type = $_POST['vehicle_type'];
    $vn = $_POST['vn'];
    $sql = "INSERT INTO service_provider (`username`, `password`, `phoneno`, `address`, `email`, `ds`, `vehicle_type`, `vn`) VALUES ('$username', '$password', '$phoneno', '$address', '$email', '$ds', '$vehicle_type', '$vn')";

    #$sql= "INSERT INTO `service_provider`( `username`, `password`, `phoneno`, `address`, `email`, `ds`, `vehicle_type`, `vn`, `Time`) VALUES ('$username','$password','$phoneno','$address','$email','$ds','$vehicle_type','$vn')";
   #$sql = "INSERT INTO `service_provider`( `username`, 'password',`phoneno`, `address`, 'email',`ds`, `vehicle_type`, `vn`) VALUES ('$username','$password','$phoneno','$address',$email,'$ds','$vehicle_type','$vn')"; 
   $result = $con->query($sql);  
    if($result) 
        echo "$username Record successfully added '\n'and its status is :  $ds ";   
   
?>

