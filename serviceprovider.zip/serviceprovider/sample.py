c = 7*1**7
print(c)