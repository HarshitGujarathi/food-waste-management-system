 <?php
if(isset($_POST['login'])) {
$con= mysqli_connect('localhost','root','','miniproject');
	$sql = mysqli_query($con,"SELECT * FROM ngo_registertable WHERE email='". $_POST["email"] . "' AND
	psw='" . $_POST["psw"] . "' ");

	$num = mysqli_num_rows($sql);

	if($num > 0) {
		$row = mysqli_fetch_array($sql);
	    if($row)
         header("location:dashboard_ngo.html");
		exit();
	}
	else {
?>
<hr>
<font color="red"><b>
		<h3>Sorry Invalid Username and Password<br>
		Please Enter Correct Credentials</br></h3>
	</b>
</font>
<hr>

<?php
      }
}
?>
<html>
 
<head>
  </head>
<style>
	 form ,input
	{
		background-color:rgba(0,0,0,0.5);
		color:white;
		 max-width: 500px;
        margin: auto;
		
	}
	  body {
             background-image: url('cover1.jpeg');
               background-repeat: no-repeat;
                background-attachment: fixed;
            background-position: center;
             background-size: 100% 100%;
        }   
		fieldset
		{
			text-align: center;
			  margin: auto;
			  	 max-width: 500px;
				 background-color:rgba(0,0,0,0.5);
		}    
		.form-login-heading 
		{
			color:white;
		}
		.btn
		{
			background-color:rgba(0,0,0,0.5);
			color:white;
		}
		.form-control,.modal-header
		{
			background-color:rgba(0,0,0,0.5);
			color:white;
		}
		.modal-body,.registration
		{
			color:red;
		}
	label
		{
			color:white;
		}
		th,p
		{
			color:white;
		}
		h1
		{
			color:red;
		}
		td
		{
			 text-align: center;
		}
		body {
    background-image: url('cover1.jpeg');
    background-repeat: no-repeat;
    background-attachment: fixed;
    background-position: center;
    background-size: 100% 100%;
    text-align: center;
    color: whitesmoke;
    background-color: rgba(0,0,0,0.5);
    font-family: Arial, sans-serif;
    position: relative; /* Make body a relative position container */
    min-height: 100vh; /* Set minimum height to 100% of the viewport height */
}

/* Your existing styles */

/* Back button styles */
 
</style>> 

  <body>
		<form method="post" action="ngo_login.php">
		<fieldset>
			<legend align="center">
				<h1 align="center">Login of NGO</h1>
			</legend>
			<table width="50%" border="1"
				align="center" style="border:thick;" class="l1">
				<tr>
					<th height="40"><label for="email" >
						Email</label>
					</th>
					<td><input type="text" name="email"
							id="email" required>
						</td>
				</tr>
				<tr><th height="40"><label for="pwd"  >Password</label>
					</th>
					<td><input type="password"name="password" id="password" required></td>
				</tr>
				<tr>
					<td colspan="2" height="40"><input
						type="submit" name="login"
						value="Login"></td>
				</tr>
				<tr>
					<td colspan="3">
						<div class="container signin">
                    <p>New user connect us? <a href= "register.html">Register here</a>.</p>
                </div>
					</td>
 


				</tr>
			</table>
		</fieldset>
	</form>
</body>
</html>



      
	 