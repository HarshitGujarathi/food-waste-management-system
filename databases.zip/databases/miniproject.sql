-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 27, 2024 at 04:15 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `miniproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `ngodecision`
--

CREATE TABLE `ngodecision` (
  `id` int(11) NOT NULL,
  `decision` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ngodecision`
--

INSERT INTO `ngodecision` (`id`, `decision`) VALUES
(1, ''),
(2, 'Reject');

-- --------------------------------------------------------

--
-- Table structure for table `ngo_registertable`
--

CREATE TABLE `ngo_registertable` (
  `ngo_id` int(11) NOT NULL,
  `uname` text NOT NULL,
  `address` text NOT NULL,
  `contact` bigint(20) NOT NULL,
  `email` text NOT NULL,
  `psw` text NOT NULL,
  `confirm_password` text NOT NULL,
  `sector` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ngo_registertable`
--

INSERT INTO `ngo_registertable` (`ngo_id`, `uname`, `address`, `contact`, `email`, `psw`, `confirm_password`, `sector`) VALUES
(1, '', 'C-31 MIDC Road no 4 Awadhan Dhule - 424006', 8007893743, 'HARSHIT.GUJRATHI67@svkmmumbai.onmicrosoft.com', '', '123', 'Non-Governmental'),
(2, '', 'C-31 MIDC Road no 4 Awadhan Dhule - 424006', 8007893743, 'HARSHIT.GUJRATHI67@svkmmumbai.onmicrosoft.com', '', '123', 'Non-Governmental'),
(3, 'ADMINngo', 'C-31 MIDC Road no 4 Awadhan Dhule - 424006', 8007893743, 'HARSHIT.GUJRATHI67@svkmmumbai.onmicrosoft.com', '', '123', 'Non-Governmental'),
(4, 'ADMINngo', 'C-31 MIDC Road no 4 Awadhan Dhule - 424006', 8007893743, 'HARSHIT.GUJRATHI67@svkmmumbai.onmicrosoft.com', '123', '123', 'Non-Governmental'),
(8, '', '', 0, '', '', '', ''),
(9, '', '', 0, '', '', '', ''),
(10, '', '', 0, '', '', '', ''),
(11, '', '', 0, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `orderuser`
--

CREATE TABLE `orderuser` (
  `id` int(11) NOT NULL,
  `tiffin` int(11) DEFAULT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orderuser`
--

INSERT INTO `orderuser` (`id`, `tiffin`, `timestamp`) VALUES
(1, 12, '2024-02-27 15:02:48');

-- --------------------------------------------------------

--
-- Table structure for table `service_provider`
--

CREATE TABLE `service_provider` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `password` int(11) NOT NULL,
  `phoneno` bigint(10) NOT NULL,
  `address` text NOT NULL,
  `email` text NOT NULL,
  `ds` text NOT NULL,
  `vehicle_type` text NOT NULL,
  `vn` text NOT NULL,
  `Time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service_provider`
--

INSERT INTO `service_provider` (`id`, `username`, `password`, `phoneno`, `address`, `email`, `ds`, `vehicle_type`, `vn`, `Time`) VALUES
(21, 'driverguju', 1234, 8007893743, 'C-31 MIDC Road no 4 Awadhan Dhule - 424006', 'HARSHIT.GUJRATHI67@svkmmumbai.onmicrosoft.com', 'ACTIVE', 'TRUCK', 'MH-18-BN-5196', '2024-02-27 14:14:16');

-- --------------------------------------------------------

--
-- Table structure for table `user_table`
--

CREATE TABLE `user_table` (
  `user_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `contact` bigint(20) NOT NULL,
  `address` text NOT NULL,
  `password` text NOT NULL,
  `confirm_password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_table`
--

INSERT INTO `user_table` (`user_id`, `name`, `email`, `contact`, `address`, `password`, `confirm_password`) VALUES
(1, 'user1', 'HARSHIT.GUJRATHI67@svkmmumbai.onmicrosoft.com', 8007893743, 'C-31 MIDC Road no 4 Awadhan Dhule - 424006', '123', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ngodecision`
--
ALTER TABLE `ngodecision`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ngo_registertable`
--
ALTER TABLE `ngo_registertable`
  ADD PRIMARY KEY (`ngo_id`);

--
-- Indexes for table `orderuser`
--
ALTER TABLE `orderuser`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_provider`
--
ALTER TABLE `service_provider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_table`
--
ALTER TABLE `user_table`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ngodecision`
--
ALTER TABLE `ngodecision`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ngo_registertable`
--
ALTER TABLE `ngo_registertable`
  MODIFY `ngo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `orderuser`
--
ALTER TABLE `orderuser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `service_provider`
--
ALTER TABLE `service_provider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `user_table`
--
ALTER TABLE `user_table`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
