<?php
    $con = mysqli_connect('localhost', 'root', '', 'miniproject');
    $name = $_POST['uname'];
    $address = $_POST['address'];
    $Ngo_contact = $_POST['Ngo_contact'];
    $email = $_POST['email'];
    $password = $_POST['psw'];
    $pswconfirm = $_POST['pswconfirm'];
    $sector = $_POST['sector'];
    
    $sql = "INSERT INTO `ngo_registertable`(`ngo_id`, `uname`, `address`, `contact`, `email`, `psw`, `confirm_password`, `sector`) VALUES (0,'$name','$address','$Ngo_contact','$email','$password','$pswconfirm','$sector')";
    
    $result = $con->query($sql);

    if ($result) {
        echo "$name Record successfully added $email and its status is: ";
    } else {
        echo "Query failed";
    }
?>
