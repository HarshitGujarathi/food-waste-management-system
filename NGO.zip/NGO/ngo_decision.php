<?php
    $con = mysqli_connect('localhost','root','','miniproject');  
    $decision =  $_POST['decision'];  
    $sql = "INSERT INTO `ngodecision`(`decision`) VALUES ('$decision')";
    $result = $con->query($sql);  
    if($result) 
        echo "$decision has been taken Succesfully added"; 
?>